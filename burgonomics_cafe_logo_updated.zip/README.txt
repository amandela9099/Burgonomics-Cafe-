Put your new logo file named image.png in this same folder as the HTML files. All logo references in the supplied pages have been updated to use image.png.
